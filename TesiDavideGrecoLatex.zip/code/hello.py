import os
import suca

print "hello world!"
print "see ya world!"
